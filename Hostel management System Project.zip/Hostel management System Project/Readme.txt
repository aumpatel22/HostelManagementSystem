Hostel Management Systen Using PHP and MySQL
Installation Steps(Configuration)
1. Download and Unzip the file on your local system.
2. Put this file inside xampp/htdocs/ .
3. Database Configuration
Open phpmyadmin
Create Database hostel.
Import database hostel.sql
Open Your browser put inside browser �http://localhost/hostel/�
Login Details
To Login as admin put inside browser �http://localhost/hostel�
Login Details for admin : admin/Test@1234
Login Details for user : test@gmail.com/Test@123