<?php
$dbuser="root";
$dbpass="";
$host="localhost";
$db="hostel";
$port = "3306";
$mysqli =new mysqli($host,$dbuser, $dbpass, $db, $port);
?>